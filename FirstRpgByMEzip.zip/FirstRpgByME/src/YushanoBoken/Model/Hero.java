package YushanoBoken.Model;

import java.util.ArrayList;

public class Hero extends Character{
    protected int mp;
    protected int maxHeroHp;
    protected boolean isDisable;
    protected Inventory inventory;
    protected ArrayList<Magic> magic;
    private int experienceNeededToLevelUp;
    private int Level;

    public Hero(HeroName heroName) {
        if (heroName == HeroName.GALAHAD) {
            setName("Galahad");
            setHp(15);
            setMaxHeroHp(15);
            setAttack(5);
            setDefense(5);
            setExperienceNeededToLevelUp(15);
        } else if (heroName == HeroName.BALIN) {
            setName("Balin");
            setHp(10);
            setMaxHeroHp(10);
            setAttack(7);
            setDefense(7);
            setExperienceNeededToLevelUp(20);
        } else if (heroName == HeroName.ELAINE) {
            setName("Elaine");
            setHp(20);
            setMaxHeroHp(20);
            setAttack(3);
            setDefense(3);
            setExperienceNeededToLevelUp(10);
        }
        setLevel(1);
        setExp(0);
        inventory = new Inventory();
        magic = new ArrayList<>();
    }

    public int getMaxHeroHp() {
        return maxHeroHp;
    }

    public void setMaxHeroHp(int maxHeroHp) {
        this.maxHeroHp = maxHeroHp;
    }

    public boolean isDisable() {
        return isDisable;
    }

    public void setDisable(boolean disable) {
        isDisable = disable;
    }

    public int getExperienceNeededToLevelUp() {
        return experienceNeededToLevelUp;
    }

    public void setExperienceNeededToLevelUp(int experienceNeededToLevelUp) {
        this.experienceNeededToLevelUp = experienceNeededToLevelUp;
    }

    public void levelUp(int exp) {
        setExp(getExp() + exp);
        if (getExp() >= getExperienceNeededToLevelUp()){
            setLevel(++Level);
            setHp(getHp() + 4);
            setAttack(getAttack() + 2);
            setDefense(getDefense() + 2);
            setExp(0);
            setExperienceNeededToLevelUp(getExperienceNeededToLevelUp() + 1);
        }
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void useItem(Item item) {
        Item items = inventory.getItem(item);
        if (items != null) {
            boolean use = items.useItem(this);
            if (use == true) {
                inventory.removeItem(item);
            }
        }
    }

    public void addItem(Item item) {
        inventory.addItem(item);
    }

    public boolean displayInventory() {
        if (!inventory.inventory.isEmpty()) {
            int index = 1;
            for (Item item : inventory.inventory) {
                System.out.println(index + ". " + item.getType());
                index++;
            }
            return true;
        }
        return false;
    }

}
