package YushanoBoken.Model;

public enum StatusEffect {
    Burn,Freeze,Paralysis,Stop,Blindness,Shield
}
