package YushanoBoken.Model;

public interface Attack {
    int Attack();
}
