package YushanoBoken.Model;

public enum BossName {
    SOLARIAS_IGNIS, VACORIUS_NEXIS, SOLARIAS_ULTIMA, SHIN_GODZILLA;
}
