package YushanoBoken.Model;

public enum SpecialAbilty {
    Burning_Pride, Chains_of_the_Void, Unstoppable_Force, Atomic_Ray;
}
