package YushanoBoken.Model;

public enum HeroName {
    GALAHAD, BALIN, ELAINE;
}
