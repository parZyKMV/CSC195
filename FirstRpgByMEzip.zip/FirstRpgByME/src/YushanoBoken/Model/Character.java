package YushanoBoken.Model;

public abstract class Character implements Attack, RecieveDamage, isDead {
    protected String name;
    protected int hp;
    protected int attack;
    protected int defense;
    protected int level = 1;
    protected int exp;
    private boolean isDisable;
    private int damageAfterDefense;
    private StatusEffect effect;
    private int durationOfEffect = 1;

    public int Attack(){
        return attack;
    }

    public void recieveDamage(int damage){
        if(damage <= 0)return;
        int defenseFactor = 2;
        int reduceDefense = this.defense/defenseFactor;
        int damageAfterDefense = Math.max(1, damage - reduceDefense);
        this.damageAfterDefense = damageAfterDefense;
        setHp(Math.max(0, this.hp - damageAfterDefense));
    }

    public boolean isDead(){
        return hp <= 0;
    }

    public void setEffect(StatusEffect effect){
        switch(effect){
            case Burn:
                if(durationOfEffect <= 3){
                    this.effect = effect;
                    setHp(this.hp - 1);
                    durationOfEffect++;
                }
                break;
            case Freeze:
                if(durationOfEffect <= 2){
                    this.effect = effect;
                    setDisable(!isDisable);
                    durationOfEffect++;
                }
                break;
            case Paralysis:
                if(durationOfEffect <= 3){

                }

        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public void setDisable(boolean disable) {
        isDisable = disable;
    }

    public int getDamageAfterDefense() {
        return damageAfterDefense;
    }
}
