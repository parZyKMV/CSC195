package YushanoBoken.Model;

public interface isDead {
    boolean isDead();
}
