package YushanoBoken.Model;

public enum EnemyType {
    SLIME, GOBLIN, SKELETON;
}
