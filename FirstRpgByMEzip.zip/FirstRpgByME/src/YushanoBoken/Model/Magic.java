package YushanoBoken.Model;

public class Magic {
    private MagicType type;
    private String statusEffect;
    private int effect;
    private StatusEffect effectType;

    public Magic(MagicType type){
        if (type == MagicType.Fire){
            effect = 3;
            statusEffect = "\uD83D\uDD25";
            effectType = StatusEffect.Burn;
        } else if (type == MagicType.Blizzard){
            effect = 2;
            statusEffect = "❄\uFE0F";
            effectType = StatusEffect.Freeze;
        }else if (type == MagicType.Thunder){
            effect = 6;
            statusEffect = "⚡";
            effectType = StatusEffect.Paralysis;
        }else if (type == MagicType.Aero){
            effect = 4;
            statusEffect = "\uD83C\uDF2A\uFE0F";
            effectType = StatusEffect.Shield;
        } else if (type == MagicType.Stop){
            statusEffect = "⌛";
            effectType = StatusEffect.Stop;
        } else if (type == MagicType.Cure){
            effect = 8;
            statusEffect = "\uD83D\uDC9A";
        }
    }

    public int getEffect() {
        return effect;
    }

    public String getStatusEffect() {
        return statusEffect;
    }

    public StatusEffect getEffectType() {
        return effectType;
    }
}
