package YushanoBoken.Model;

public enum MagicType {
    Fire, Blizzard, Thunder, Aero, Cure, Stop;
}
