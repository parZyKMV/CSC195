package YushanoBoken.Model;

public enum ItemsType {
    POTION, ATTACK_STONE, DEFENSE_STONE;
}
