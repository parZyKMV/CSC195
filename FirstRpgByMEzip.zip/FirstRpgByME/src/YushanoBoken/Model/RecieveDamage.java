package YushanoBoken.Model;

public interface RecieveDamage {
    void recieveDamage(int damage);
}
