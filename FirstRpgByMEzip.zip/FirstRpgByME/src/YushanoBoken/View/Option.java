package YushanoBoken.View;

public enum Option {
    Attack, Use_Item, Magic;
}
