package YushanoBoken.View;

import YushanoBoken.Controller.YushanoBokenController;
import YushanoBoken.Model.*;

import java.util.Scanner;

public class YushanoBokenUI {
    private Scanner userInput = new Scanner(System.in);
    private YushanoBokenController controller = new YushanoBokenController();
    private int turn;
    private Hero hero;


    public void run(){
        System.out.println("Welcome to Yushano Boken!");
        System.out.println("Please chose one of the next Heroes");
        showHeroes();
        HeroName heroName = choseAHero();
        hero = new Hero(heroName);
        System.out.println("You chose " + heroName + "\n");
        Item potion = new Item(ItemsType.ATTACK_STONE);
        hero.addItem(potion);
        turn = controller.startGame(hero);
        while (!hero.isDead()){
            if(turn == 0){
                updateHeroStats(hero);
                showOptions();
                Option option = choseAOption();
                turn = controller.HeroTurn(option);

            } else if (turn == 1) {
                turn = controller.EnemiesTurn();
            }
        }
        System.out.println("Game Over!");
        System.out.println("Do you want to play again? (Yes/No)");
        String answer = userInput.nextLine();
        if (answer.equalsIgnoreCase("Yes")) {
            run();
        }else if (answer.equalsIgnoreCase("No")) {
            System.exit(0);
        }
    }

    public void showHeroes(){
        System.out.println("Heroes:");
        StringBuilder galahad = new StringBuilder();
        galahad.append("Hero #1 : \n Name: Galahad\n Health: 15 \n Attack: 5 \n Defense: 5");
        StringBuilder balin = new StringBuilder();
        balin.append("Hero #2 : \n Name: Balin\n Health: 10 \n Attack: 7 \n Defense: 7");
        StringBuilder elaine = new StringBuilder();
        elaine.append("Hero #3 : \n Name: Elaine \n Health: 20 \n Attack: 3 \n Defense: 3 ");
        System.out.println(galahad.toString() + "\n" + balin.toString() + "\n" + elaine.toString());
    }

    public HeroName choseAHero(){
        String choice = userInput.nextLine();
        return heroName(choice);
    }

    public HeroName heroName(String choice){
        int optionIndex = 0;
        try {
            optionIndex = Integer.parseInt(choice);
        }catch (NumberFormatException e){
            System.out.println("Please enter a valid option!");
            return choseAHero();
        }
        HeroName[] options = HeroName.values();
        try {
            return options[optionIndex - 1];
        }catch (IndexOutOfBoundsException e){
            System.out.println("Please enter a valid option!");
            System.out.println("Enter a number between 1 and " + options.length + ".");
            return choseAHero();
        }
    }

    public void showOptions(){
        System.out.println("Your options:");
        System.out.println("1. Attack");
        System.out.println("2. Use item");
        if (hero.getLevel() >= 2){
            System.out.println("3. Magic");
        }

    }

    public Option choseAOption(){
        String option = userInput.nextLine();
        return chosenOption(option);
    }

    public Option chosenOption(String option){
        int optionIndex = 0;
        try {
            optionIndex = Integer.parseInt(option);
        }catch (NumberFormatException e){
            System.out.println("Please enter a valid option!");
            return choseAOption();
        }
        Option[] options = Option.values();
        try {
            return options[optionIndex - 1];
        }catch (IndexOutOfBoundsException e){
            System.out.println("Please enter a valid option!");
            System.out.println("Enter a number between 1 and " + options.length + ".");
            return choseAOption();
        }
    }

    public void updateHeroStats(Hero hero){
        StringBuilder stats = new StringBuilder();
        stats.append("Name: " + hero.getName() + "\n");
        stats.append("Level: " + hero.getLevel() + "\n");
        stats.append("HP: " + hero.getHp() + "\n");
        stats.append("ATTACK: " + hero.getAttack() + "\n");
        stats.append("DEFENSE: " + hero.getDefense() + "\n");
        stats.append("EXP: " + hero.getExp() + "\n");
        System.out.println(stats);
    }

}
