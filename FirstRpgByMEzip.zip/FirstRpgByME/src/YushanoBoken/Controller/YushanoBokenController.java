package YushanoBoken.Controller;

import YushanoBoken.Model.*;
import YushanoBoken.View.Option;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class YushanoBokenController{
    private Scanner userInput = new Scanner(System.in);
    private int turn = 0;
    private Enemy enemy;
    private Hero hero;
    private Boss boss;
    private int level = 1;


    public int startGame(Hero hero) {
        this.hero = hero;
        generateEnemiesOrBoss();
        presentEnemyOrBoss();
        return turn = 0;
    }

    public int HeroTurn(Option option){
        if(hero.isDisable()){
            return turn = 1;
        }
        if(option == Option.Attack){
            if (enemy != null) {
                enemy.recieveDamage(hero.getAttack());
                updateEnemyAndBossHealth();
                if (enemy.isDead()){
                    System.out.println(enemy.getName() + " is Dead \n");
                    Item item = enemy.dropLoot();
                    hero.addItem(item);
                    System.out.println("You recieve " + item);
                    hero.levelUp(enemy.getExp());
                    System.out.println("You got " + enemy.getExp() + " exp");
                    enemy = null;
                    generateEnemiesOrBoss();
                    presentEnemyOrBoss();
                    return turn = 0;
                }
            } else if (boss != null) {
                boss.recieveDamage(hero.getAttack());
                updateEnemyAndBossHealth();
                if (boss.isDead()){
                    Item item = boss.dropLoot();
                    hero.addItem(item);
                    System.out.println("You recieve " + item);
                    hero.levelUp(boss.getExp());
                    System.out.println("You got " + boss.getExp() + " exp");
                    System.out.println("CONGRATULATIONS \n" + "You have defeat " + boss.getName() + "\n");
                    boss = null;
                    generateEnemiesOrBoss();
                    presentEnemyOrBoss();
                    return turn = 0;
                }
            }
        } else if (option == Option.Use_Item){
            boolean isInventoryEmpty = hero.displayInventory();
            if (isInventoryEmpty == true){
                System.out.println("Chose an item # \n");
                Item item = choseAOption();
                hero.useItem(item);
            }else{
                System.out.println("You don't have items in your inventory \n");
                return turn = 0;
            }
        }
        return turn = 1;
    }

    public Item choseAOption(){
        String option = userInput.nextLine();
        return chosenOption(option);
    }

    public Item chosenOption(String option) {
        int optionIndex = 0;
        try {
            optionIndex = Integer.parseInt(option);
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number!");
            return choseAOption();
        }
        Inventory heroInventory = hero.getInventory();
        ArrayList<Item> items = heroInventory.getItems();
        if (optionIndex < 1 || optionIndex > items.size()) {
            System.out.println("Please enter a valid option!");
            System.out.println("Enter a number between 1 and " + items.size() + ".");
            return choseAOption();
        }

        return items.get(optionIndex - 1);
    }

    public int EnemiesTurn(){
        if (enemy != null) {
            hero.recieveDamage(enemy.getAttack());
            System.out.println("You have received " + hero.getDamageAfterDefense() + " damage");
            return turn = 0;
        } else if (boss != null) {
            Random rand = new Random();
            int useSpecialAbility = rand.nextInt(3) + 1;
            if (useSpecialAbility == 3) {
                boss.useSpecialAbility(hero);
                System.out.println(boss.getName() + " uses " + boss.getAbilty() + " special");
            } else {
                hero.recieveDamage(boss.getAttack());
                System.out.println("You have received " + hero.getDamageAfterDefense() + " damage");
            }
        }
        return turn = 0;
    }

    public void generateEnemiesOrBoss(){
        if(enemy == null || boss == null || enemy.isDead() || boss.isDead()){
            Random rand = new Random();
            int generateEnemiesOrBoss = rand.nextInt(5) + 1;
            if(hero.getLevel() >= 10){
                if (generateEnemiesOrBoss == 4 || generateEnemiesOrBoss == 5) {
                    if (hero.getLevel() >= 10 && hero.getLevel() <= 20) {
                        boss = new Boss(BossName.SOLARIAS_IGNIS);
                    } else if (hero.getLevel() >= 20 && hero.getLevel() <= 30) {
                        boss = new Boss(BossName.VACORIUS_NEXIS);
                    } else if (hero.getLevel() >= 30 && hero.getLevel() <= 40) {
                        boss = new Boss(BossName.SOLARIAS_ULTIMA);
                    } else if (hero.getLevel() >= 50 && hero.getLevel() <= 100) {
                        boss = new Boss(BossName.SHIN_GODZILLA);
                    }
                }

            }else{
                EnemyType[] enemyTypes = EnemyType.values();
                int enemies = rand.nextInt(enemyTypes.length);
                this.enemy = new Enemy(enemyTypes[enemies]);
                if (hero.getLevel() >= 5){
                    enemy.levelUp(getLevel());
                    setLevel(getLevel());
                }
            }
        }
    }

    public void setLevel(int level){
        this.level = ++level;
    }

    public int getLevel(){
        return level;
    }

    public void updateEnemyAndBossHealth(){
        StringBuilder hp = new StringBuilder();
        if (enemy != null) {
            hp.append(enemy.getName());
            hp.append("\n");
            hp.append("HP: " + enemy.getHp());
            System.out.println(hp + "\n");
        } else if (boss != null) {
            hp.append(boss.getName());
            hp.append("\n");
            hp.append("HP:" + boss.getHp());
            System.out.println(hp + "\n");
        }
    }

    public void presentEnemyOrBoss(){
        StringBuilder displayEnemyInfo = new StringBuilder();
        if (enemy != null) {
            displayEnemyInfo.append("An enemy has appeared: \n");
            displayEnemyInfo.append(enemy.getName() + "\n");
            displayEnemyInfo.append(enemy.getHp() + " hp"+ "\n");
            System.out.println(displayEnemyInfo + "\n");
        } else if (boss != null){
            displayEnemyInfo.append("----------------------DANGER---------------------------- \n");
            displayEnemyInfo.append("A boss has appeared: ");
            displayEnemyInfo.append(boss.getName() + "\n");
            displayEnemyInfo.append(boss.getHp() + " hp" + "\n");
            System.out.println(displayEnemyInfo + "\n");
        }
    }

}
