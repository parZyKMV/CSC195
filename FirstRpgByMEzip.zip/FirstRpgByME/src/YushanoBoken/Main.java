package YushanoBoken;

import YushanoBoken.View.YushanoBokenUI;

public class Main {
    public static void main(String[] args) {
        new YushanoBokenUI().run();
    }
}
